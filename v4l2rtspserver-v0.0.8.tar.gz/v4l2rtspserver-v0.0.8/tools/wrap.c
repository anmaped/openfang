#include <stdlib.h>
#include <ctype.h>


unsigned short int * __ctype_b(void)
{
	return __ctype_b_loc();
}

__int32_t  * __ctype_tolower(void)
{
	return __ctype_tolower_loc();
}
