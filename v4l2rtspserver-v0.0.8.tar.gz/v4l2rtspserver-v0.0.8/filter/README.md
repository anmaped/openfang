# free-nross
Free noise reduction of speech signals

This library provides ability of noise reduction of speech signals.
It has been implemented to suppress noise in one way speech signal
system (i.e. system without reference source of noise signal). It 
may be usefull for telephony terminals, that work in noisy
environment and have single microphone.

Note: this noise suppressor has been created to work well only for
speech signals.

free-nross includes C and MATLAB/Octave/FreeMat code sources.

(c) Sergei Mashkin, 2015
