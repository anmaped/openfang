/* ---------------------------------------------------------------------------
** This software is in the public domain, furnished "as is", without technical
** support, and with no warranty, express or implied, as to its usefulness for
** any purpose.
**
** logger.cpp
** 
** -------------------------------------------------------------------------*/

#include "logger.h"

#ifndef HAVE_LOG4CPP
int LogLevel=NOTICE;
#endif
